default['java']['package_name'] = 'oracle-java7-installer'
default['java']['repo_name'] = 'ppa:webupd8team/java'
default['java']['path'] = 'JAVA_HOME="/usr/lib/jvm/java-7-oracle"'

default['tomcat']['package1'] = 'tomcat6'
default['tomcat']['package2'] = 'tomcat6-docs'
default['tomcat']['package3'] = 'tomcat6-admin'
default['tomcat']['package4'] = 'tomcat6-examples'
default['tomcat']['env']['path'] = '/etc/default/tomcat6'

default['tomcat']['username'] = 'admin'
default['tomcat']['password'] = 'password'
default['tomcat']['roles'] = 'manager-gui,admin-gui'

#default['tomcat']['webapps'] = '/var/lib/tomcat6/webapps/benefits.war'
#default['warfile']['location'] = 'http://www.oracle.com/webfolder/technetwork/tutorials/obe/fmw/wls/12c/03-#DeployApps/files/benefits.war'
