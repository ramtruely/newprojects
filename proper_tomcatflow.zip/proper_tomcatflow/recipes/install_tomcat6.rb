package [ node['tomcat']['package1'], node['tomcat']['package2'], node['tomcat']['package3'], node['tomcat']['package4'] ]

file node['tomcat']['env']['path'] do
  content node['java']['path']
  end

log 'install tomcat (install_tomcat6.rb)'

 #template '/etc/tomcat6/tomcat-users.xml' do
 # source 'tomcat-users.erb'
 # owner 'root'
 # mode '0777'
 # action :create
#end

 #file '/etc/tomcat6/tomcat-users.xml' do
  #content '<tomcat-users>
   # <user username="admin" password="password" roles="manager-gui,admin-gui"/>
#</tomcat-users>'
#end



service node['tomcat']['package1'] do
action :restart
end

