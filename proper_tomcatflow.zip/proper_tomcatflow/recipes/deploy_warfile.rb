#deploying war file

package = node['tomcat']['package1']

remote_file node['tomcat']['webapps'] do
  source node['warfile']['location']
  owner 'root'
  group 'root'
  mode '0755'
  action :create_if_missing
  notifies :restart, "service[#{package}]"
  #notifies :restart, "service[node['tomcat']['package1']]"
end

log 'deployed war file (deploy_warfile.rb)'