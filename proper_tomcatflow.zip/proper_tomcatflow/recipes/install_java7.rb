apt_repository 'repo_name' do
    uri node['java']['repo_name']
    end

log 'added java repository (install_java7.rb)'

    bash 'licence_agreement' do
      code <<-EOH
echo debconf shared/accepted-oracle-license-v1-1 select true | sudo debconf-set-selections
echo debconf shared/accepted-oracle-license-v1-1 seen true | sudo debconf-set-selections
      EOH
      action :run
    end

log 'configured licence aggrement'

    package node['java']['package_name'] do
      action :install
    end
    
    
   file '/etc/environment' do
     content node['java']['path']
     action :create
   end
    
    log 'installed java'