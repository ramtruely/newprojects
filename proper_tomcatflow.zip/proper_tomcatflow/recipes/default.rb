#
# Cookbook:: proper_tomcatflow
# Recipe:: default
#
# Copyright:: 2017, The Authors, All Rights Reserved.

log '    >>>>>>>>>>   READING DEFAULT.RB >>>>>>>>>>>>>>      '

include_recipe 'proper_tomcatflow::install_java7'
include_recipe 'proper_tomcatflow::install_tomcat6'
#include_recipe 'proper_tomcatflow::deploy_warfile'