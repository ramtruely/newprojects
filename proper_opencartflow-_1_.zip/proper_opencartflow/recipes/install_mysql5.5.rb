

bash 'install_something' do
  user 'root'
  cwd '/var/www/html/'
  code <<-EOH

git clone https://github.com/opencart/opencart.git

  export DEBIAN_FRONTEND="noninteractive"

sudo debconf-set-selections <<< "mysql-server mysql-server/root_password password $1"
sudo debconf-set-selections <<< "mysql-server mysql-server/root_password_again password $1"
EOH
end

package [ node['package3']]

service node['package3_service'] do
  action :restart
end

service node['package1']  do
    action :restart
    end