package [ node['package2']]
package [ node['package4']]
package [ node['package2_dependencies']]

bash 'name' do
  code <<-EOH
  sudo updatedb
  j=$(locate mcrypt.so | grep php5)
i=$(echo "extension = ")

echo $i$j > /etc/php5/mods-available/mcrypt.ini


sudo php5enmod mcrypt
  EOH
  action :run
end
