bash 'name' do
  code <<-EOH
  mv /var/www/html/opencart/upload/config-dist.php /var/www/html/opencart/upload/config.php
mv /var/www/html/opencart/upload/admin/config-dist.php /var/www/html/opencart/upload/admin/config.php

chmod 777 /var/www/html/opencart/upload/image/
chmod 777 /var/www/html/opencart/upload/image/cache/
chmod 777 /var/www/html/opencart/upload/image/catalog/
chmod 777 /var/www/html/opencart/upload/system/storage/cache/
chmod 777 /var/www/html/opencart/upload/system/storage/logs/
chmod 777 /var/www/html/opencart/upload/system/storage/download/
chmod 777 /var/www/html/opencart/upload/system/storage/upload/
chmod 777 /var/www/html/opencart/upload/system/storage/modification/
chmod 777 /var/www/html/opencart/upload/config.php
chmod 777 /var/www/html/opencart/upload/admin/config.php
  EOH
  action :run
end
