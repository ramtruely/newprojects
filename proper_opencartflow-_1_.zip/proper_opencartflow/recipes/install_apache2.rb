package node['package1'] do
  action :install
end

service node['package1'] do
  action :restart
end
