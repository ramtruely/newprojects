#
# Cookbook:: proper_opencartflow
# Recipe:: default
#
# Copyright:: 2017, The Authors, All Rights Reserved.
 
 include_recipe 'proper_opencartflow::install_apache2'
 include_recipe 'proper_opencartflow::install_php5'
 include_recipe 'proper_opencartflow::install_mysql5.5'
 include_recipe 'proper_opencartflow::configure_opencart'