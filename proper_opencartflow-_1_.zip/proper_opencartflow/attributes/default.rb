default['package1'] = 'apache2'
default['package2'] = 'php5'
default['package3'] = 'mysql-server'
default['package3_service'] = 'mysql'
default['package4'] = 'git'
default['package2_dependencies'] = ['php5-GD' , 'php5-cURL' , 'php5-mCrypt', 'php5-mysql']


